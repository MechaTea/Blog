const AboutPage = () => {
    return (
        <h1>This is the about page!</h1>
    )
}

export default AboutPage;