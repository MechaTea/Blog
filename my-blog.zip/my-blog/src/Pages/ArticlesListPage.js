const ArticlesListPage = () => {
    return (
        <h1>This is the articles list page!</h1>
    )
}

export default ArticlesListPage;